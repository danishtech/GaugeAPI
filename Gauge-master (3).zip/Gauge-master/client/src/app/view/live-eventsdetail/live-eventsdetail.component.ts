import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-live-eventsdetail',
  templateUrl: './live-eventsdetail.component.html',
  styleUrls: ['./live-eventsdetail.component.css']
})
export class LiveEventsdetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
