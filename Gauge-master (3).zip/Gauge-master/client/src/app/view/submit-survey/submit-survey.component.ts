import { Component, OnInit } from '@angular/core';
import {CategoriesService} from '../../controllers/categories.service'
import { Categories } from '../../models/categories.model'

@Component({
  selector: 'app-submit-survey',
  templateUrl: './submit-survey.component.html',
  styleUrls: ['./submit-survey.component.css'],
  providers: [CategoriesService]
})

export class SubmitSurveyComponent implements OnInit {

  submitPage: any;
  categories: Categories;
  temAnswer: any;

  constructor(private _categoryService: CategoriesService) { }

  ngOnInit() {
    this.submitPage = 'A';
    this.refresh();
  }

  async refresh() {
    const data = this._categoryService.getCategories().then( data => {
      this.categories = data;
      console.log(this.categories)
      for(var i = 0; i < data.length; i++){
        this.temAnswer = data[i].Answers.split(',');
        // console.log(this.temAnswer);
      }
    });
  }

  nextStep(val: any) {
    console.log(val)
    switch(val) {
      case 'A':
        this.submitPage = 'A';
        break;
      case 'B':
        console.log("here in B")
        this.submitPage = 'B';
        break;
      case 'C':
        this.submitPage = 'C';
        break;
      case 'D':
        this.submitPage = 'D';
        break;
      case 'E':
        this.submitPage = 'E';
        break;
    }
  }

}
