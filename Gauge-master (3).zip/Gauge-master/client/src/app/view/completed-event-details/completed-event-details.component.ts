import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-event-details',
  templateUrl: './completed-event-details.component.html',
  styleUrls: ['./completed-event-details.component.css']
})
export class CompletedEventDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
