import { Component, OnInit } from '@angular/core';
import * as CanvasJS from '../../../canvasjs.min';
import { SchoolService } from '../../../controllers/schools.service'

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css'],
  providers: [SchoolService]
})
export class AdminDashboardComponent implements OnInit {

  constructor(private _schoolService: SchoolService) { }

  ngOnInit() {
    this.chart();
    this.refresh();
  }

  async refresh() {
    const data = this._schoolService.getSchool();
    console.log(data);
  }

  async chart() {

    var chart = new CanvasJS.Chart("donutChart", {
      animationEnabled: true,
      title: {
        horizontalAlign: "left"
      },
      data: [{
        type: "doughnut",
        startAngle: 60,
        //innerRadius: 60,
        indexLabelFontSize: 17,
        indexLabel: "{label} - #percent%",
        toolTipContent: "<b>{label}:</b> {y} (#percent%)",
        dataPoints: [
          { y: 700, label: "Event Development" },
          { y: 500, label: "Economic Development" },
          { y: 400, label: "Sport Development" },
          { y: 600, label: "Social Development" },
          { y: 300, label: "Branding Development" },
        ]
      }]
    });
    chart.render();

  }

}
