import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-submit-events',
  templateUrl: './submit-events.component.html',
  styleUrls: ['./submit-events.component.css']
})
export class SubmitEventsComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit() {
  }

  eventDetail(val: any) {
    switch(val){
      case '0': 
        this.router.navigateByUrl('/live-events');
        break;
      case '1':
        this.router.navigateByUrl('/upcoming-events');
        break;
      case '2':
        this.router.navigateByUrl('/complete-events');
    }
  }

}
