import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-upcoming-events-detail',
  templateUrl: './upcoming-events-detail.component.html',
  styleUrls: ['./upcoming-events-detail.component.css']
})
export class UpcomingEventsDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
