import { Component, OnInit } from '@angular/core';
import * as CanvasJS from '../../../canvasjs.min'

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.css']
})
export class AdminDashboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    this.chart();
  }

  async chart() {

    var chart = new CanvasJS.Chart("donutChart", {
      animationEnabled: true,
      title: {
        horizontalAlign: "left"
      },
      data: [{
        type: "doughnut",
        startAngle: 60,
        //innerRadius: 60,
        indexLabelFontSize: 17,
        indexLabel: "{label} - #percent%",
        toolTipContent: "<b>{label}:</b> {y} (#percent%)",
        dataPoints: [
          { y: 700, label: "Event Development" },
          { y: 500, label: "Economic Development" },
          { y: 400, label: "Sport Development" },
          { y: 600, label: "Social Development" },
          { y: 300, label: "Branding Development" },
        ]
      }]
    });
    chart.render();

  }

}
