import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-completed-survey',
  templateUrl: './completed-survey.component.html',
  styleUrls: ['./completed-survey.component.css']
})
export class CompletedSurveyComponent implements OnInit {

  submitPage: any;

  constructor() { }

  ngOnInit() {
    this.submitPage = 'A';
  }

  nextStep(val: any) {
    console.log(val)
    switch (val) {
      case 'A':
        this.submitPage = 'A';
        break;
      case 'B':
        console.log("here in B")
        this.submitPage = 'B';
        break;
      case 'C':
        this.submitPage = 'C';
        break;
      case 'D':
        this.submitPage = 'D';
        break;
      case 'E':
        this.submitPage = 'E';
        break;
    }
  }

}
