import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-submit-survey',
  templateUrl: './submit-survey.component.html',
  styleUrls: ['./submit-survey.component.css']
})
export class SubmitSurveyComponent implements OnInit {

  submitPage: any;

  constructor() { }

  ngOnInit() {
    this.submitPage = 'A';
  }

  nextStep(val: any) {
    console.log(val)
    switch(val) {
      case 'A':
        this.submitPage = 'A';
        break;
      case 'B':
        console.log("here in B")
        this.submitPage = 'B';
        break;
      case 'C':
        this.submitPage = 'C';
        break;
      case 'D':
        this.submitPage = 'D';
        break;
      case 'E':
        this.submitPage = 'E';
        break;
    }
  }

}
